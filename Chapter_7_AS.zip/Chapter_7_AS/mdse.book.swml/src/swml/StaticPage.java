/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package swml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Static Page</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see swml.SwmlPackage#getStaticPage()
 * @model
 * @generated
 */
public interface StaticPage extends Page
{
} // StaticPage
