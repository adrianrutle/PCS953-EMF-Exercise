/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package swml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NC Link</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see swml.SwmlPackage#getNCLink()
 * @model
 * @generated
 */
public interface NCLink extends Link
{
} // NCLink
