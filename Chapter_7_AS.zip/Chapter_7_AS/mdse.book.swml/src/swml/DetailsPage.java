/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package swml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Details Page</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see swml.SwmlPackage#getDetailsPage()
 * @model
 * @generated
 */
public interface DetailsPage extends DynamicPage
{
} // DetailsPage
