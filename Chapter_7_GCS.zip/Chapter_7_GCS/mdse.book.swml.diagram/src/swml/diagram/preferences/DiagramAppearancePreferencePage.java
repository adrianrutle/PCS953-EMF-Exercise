/*
 * 
 */
package swml.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import swml.diagram.part.SwmlDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(SwmlDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
