/*
 * 
 */
package swml.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import swml.diagram.part.SwmlDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(SwmlDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
