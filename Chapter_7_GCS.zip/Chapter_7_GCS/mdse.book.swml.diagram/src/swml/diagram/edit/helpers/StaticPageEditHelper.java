/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class StaticPageEditHelper extends SwmlBaseEditHelper {
}
