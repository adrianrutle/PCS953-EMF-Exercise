/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class ClassEditHelper extends SwmlBaseEditHelper {
}
