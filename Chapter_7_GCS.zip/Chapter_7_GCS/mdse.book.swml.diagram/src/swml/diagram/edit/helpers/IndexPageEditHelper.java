/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class IndexPageEditHelper extends SwmlBaseEditHelper {
}
