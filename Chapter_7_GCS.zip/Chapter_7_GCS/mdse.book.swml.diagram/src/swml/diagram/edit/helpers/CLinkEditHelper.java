/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class CLinkEditHelper extends SwmlBaseEditHelper {
}
