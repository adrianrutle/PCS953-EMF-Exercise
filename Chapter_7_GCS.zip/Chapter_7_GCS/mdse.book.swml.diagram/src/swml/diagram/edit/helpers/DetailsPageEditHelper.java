/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class DetailsPageEditHelper extends SwmlBaseEditHelper {
}
