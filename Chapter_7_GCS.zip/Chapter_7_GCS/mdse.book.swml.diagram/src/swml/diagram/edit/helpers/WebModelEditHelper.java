/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class WebModelEditHelper extends SwmlBaseEditHelper {
}
