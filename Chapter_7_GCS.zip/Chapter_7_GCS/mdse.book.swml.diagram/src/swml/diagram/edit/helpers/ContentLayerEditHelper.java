/*
 * 
 */
package swml.diagram.edit.helpers;

/**
 * @generated
 */
public class ContentLayerEditHelper extends SwmlBaseEditHelper {
}
